**Important:** Pull Requests should _only_ be issued against the `dev` branch. PRs against the master branch will always be closed.

This PR changes (delete as applicable)

* Documentation
* TypeScript Defs
* The public-facing API
* Nothing, it's a bug fix

Describe the changes below:

